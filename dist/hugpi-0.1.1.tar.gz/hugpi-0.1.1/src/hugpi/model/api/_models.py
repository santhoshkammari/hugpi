from ..base._base_llm import BaseHuggyLLM

class HUGPiLLM(BaseHuggyLLM):
    pass
